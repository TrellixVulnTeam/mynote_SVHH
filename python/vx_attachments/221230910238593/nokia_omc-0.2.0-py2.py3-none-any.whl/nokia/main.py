from .nokia_func.args import network, sqlfile, HOME, update, omc_list
from .nokia_func.function_run_time import print_run_time
import os

@print_run_time
def main():
    print('----------------------')
    print('|  当前网络类型为%sG  |' % str(network))
    print('----------------------')
    # 配置文件存在且输入了sql脚本
    if sqlfile and os.path.exists(
        '%s\\.omc账号密码-%s.pickle' %
            (HOME, network)):
        from .nokia_func.multithreading_con_exec import multi_threading_con_omc, multi_threading_exec_select, multithreading_exec_drop, multithreading_exec_create
        from .nokia_func.parseSQL import parse_sqlfile, get_type
        con_list = multi_threading_con_omc(omc_list)
        sql_list = parse_sqlfile(sqlfile)
        for sql in sql_list:
            sql_type = get_type(sql)
            if sql_type == 'DROP':
                multithreading_exec_drop(con_list, sql)
            elif sql_type == 'CREATE':
                multithreading_exec_create(con_list, sql)
            elif sql_type == 'SELECT':
                data_list = multi_threading_exec_select(con_list, sql)
                from .nokia_func.save_data import save_data
                save_data(data_list)
        #关闭oracle 连接
        for con, omc in con_list:
            con.close()
    # 只更新配置文件
    elif update and not sqlfile:
        from .nokia_func.config_function import update_config
        update_config(update)
        print('配置文件更新成功...')

    # 输入了脚本参数，未发现omc账号密码文件
    elif sqlfile and not (os.path.exists('%s\\.omc账号密码-%s.pickle' % (HOME, network))):
        raise SystemExit('未找到配置文件，请先更新配置文件...')
    # 更新配置文件并查询数据
    elif update and sqlfile:
        from .nokia_func.config_function import update_config
        update_config(update)

        from .nokia_func.multithreading_con_exec import multi_threading_con_omc, multi_threading_exec_select, \
            multithreading_exec_drop, multithreading_exec_create
        from .nokia_func.parseSQL import parse_sqlfile, get_type
        con_list = multi_threading_con_omc(omc_list)
        sql_list = parse_sqlfile(sqlfile)
        for sql in sql_list:
            sql_type = get_type(sql)
            if sql_type == 'DROP':
                multithreading_exec_drop(con_list, sql)
            elif sql_type == 'CREATE':
                multithreading_exec_create(con_list, sql)
            elif sql_type == 'SELECT':
                data_list = multi_threading_exec_select(con_list, sql)
                from .nokia_func.save_data import save_data
                save_data(data_list)
        for con, omc in con_list:
            con.close()
    else:
        raise SystemExit('请输入-h参数查看使用帮助...')


if __name__ == "__main__":
    main()

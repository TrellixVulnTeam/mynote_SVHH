from pathlib import PurePath
import pandas as pd
import time
import os
from .args import savepath, sqlfile


def save_data(data_list):
    df = pd.DataFrame(data_list)
    dir = PurePath(savepath)
    df.to_csv(
        str(dir) +
        '/' +
        os.path.splitext(
            os.path.basename(sqlfile))[0] +
        '-%s.csv' %
        time.strftime(
            "%Y%m%d%H%M%S",
            time.localtime()),
        encoding='gb18030',
        index=False,header=None)
    print('查询结果已保存至%s' % os.path.abspath(savepath))

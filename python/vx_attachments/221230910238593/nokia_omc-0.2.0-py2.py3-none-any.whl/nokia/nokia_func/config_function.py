import json
import pickle
import os
from .args import network, HOME


def update_config(config_file):
    """
    打开json配置文件，使用pickle模块将内容写入用户目录下持久保存
    """
    with open(config_file, 'r') as f1, open('%s\\.omc账号密码-%s.pickle' % (HOME, network), 'wb') as f2:
        d = json.loads(f1.read())
        pickle.dump(d, f2)


# 每次执行查询前需从本地读取omc的配置文件
def read_omc_config():
    if os.path.exists(
            '%s\\.omc账号密码-%s.pickle' %
            (HOME, network)):
        with open('%s\\.omc账号密码-%s.pickle' % (HOME, network), 'rb') as f:
            dic = pickle.load(f)
            return dic
    else:
        raise SystemExit('未找到配置文件')

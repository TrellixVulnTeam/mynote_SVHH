from concurrent.futures import ThreadPoolExecutor, as_completed
from .con_exec import exec_select_sql, exec_drop_sql, exec_create_sql, con_omc

# 多线程连接omc返回omc连接信息和omc标识


def multi_threading_con_omc(omc_list):
    active_con_list = []
    with ThreadPoolExecutor(max_workers=13) as t:
        obj_list = []
        for omc in omc_list:
            obj = t.submit(con_omc, omc)
            obj_list.append(obj)
        for future in as_completed(obj_list):
            data = future.result()
            active_con_list.append(data)
    return active_con_list


def multithreading_exec_drop(con_list, sql):
    with ThreadPoolExecutor(max_workers=13) as t:
        for con, omc in con_list:
            print(format(omc,'<6') + 'drop table...')
            t.submit(exec_drop_sql, con, sql)


def multithreading_exec_create(con_list, sql):
    with ThreadPoolExecutor(max_workers=13) as t:
        obj_list = []
        for con, omc in con_list:
            print(format(omc,'<6') + 'create table...')
            obj = t.submit(exec_create_sql, con, sql)
            obj_list.append(obj)
        for future in as_completed(obj_list):
            future.result()


def multi_threading_exec_select(con_list, sql):
    data_list = []
    with ThreadPoolExecutor(max_workers=13) as t:
        obj_list = []
        for con in con_list:
            print(format(con[1],'<6') + 'select table...')
            obj = t.submit(exec_select_sql, con, sql)
            obj_list.append(obj)
        for idx, future in enumerate(as_completed(obj_list)):
            data = future.result()
            if idx == 0:
                # 第一次循环 把表头append到data_list
                data_list.append(data[0])
                # 对数据部分进行遍历，把每行数据append到data_list
                for datas in data[1:]:
                    for data in datas:
                        data_list.append(data)
            else:
                for datas in data[1:]:
                    for data in datas:
                        data_list.append(data)
    return data_list

import cx_Oracle as cx
import re
from .config_function import read_omc_config
from .args import sdate, rowsize
omc_dic = read_omc_config()


def con_omc(omc: str):
    """
    连接omc，返回连接信息和omc信息
    """
    try:
        con = cx.connect(
            omc_dic[omc][0],
            omc_dic[omc][1],
            omc_dic[omc][2],
            encoding="UTF-8")
        return (con, omc)
    except Exception as ex:
        print(ex)


def exec_drop_sql(con, sql):
    with con.cursor() as cur:
        try:
            cur.execute(sql.split(';')[0])
        except Exception as ex:
            print(ex)


def exec_create_sql(con, sql):
    with con.cursor() as cur:
        try:
            if "&" in sql:  # create语句中有绑定变量情况
                str1 = re.sub(
                    r"&.*?,", sdate[0] + ',', sql.split(';')[0], count=1)
                str2 = re.sub(r"&.*?,", sdate[1] + ',', str1, count=1)
                cur.execute(str2)
                print('create table 成功')
            else:  # create语句中没有绑定变量情况
                cur.execute(sql.split(';')[0])
        except Exception as ex:
            raise SystemExit(ex)


def exec_select_sql(con: tuple, sql: str):
    data_list = []
    with con[0].cursor() as cur:
        try:
            if "&" in sql and sdate:
                cur.execute(sql.split(';')[0], (sdate[0], sdate[1]))
            else:
                cur.execute(sql.split(';')[0])
            # 获取表头信息
            title = [i[0] for i in cur.description]
            title_list = title + ['omc归属']
            while True:
                rows = cur.fetchmany(rowsize)
                if not rows:
                    break
                for row in rows:
                    row_list = list(row)
                    row_list.append(con[1])
                    data_list.append(row_list)
            # 返回数据和表头信息
            return (title_list, data_list)
        except Exception as ex:
            raise SystemExit(ex)


# def _test_sql(sqlfile):
#     sql_list = parse_sqlfile(sqlfile)
#     for sql in sql_list:
#         sql_type = get_type(sql)
#         if sql_type == 'DROP':
#             print('sql类型为%s' % sql_type)
#             print(sql)
#         elif sql_type == 'CREATE':
#             print('sql类型为%s' % sql_type)
#             if "&" in sql:
#                 str1 = re.sub(
#                     r"&.*?,", sdate[0] + ',', sql.split(';')[0], count=1)
#                 str2 = re.sub(r"&.*?,", sdate[1] + ',', str1, count=1)
#                 print(str2)
#                 print('create table 成功')
#             else:
#                 print(sql)
#         elif sql_type == 'SELECT':
#             print('sql类型为%s' % sql_type)
#             print(sql)
#         else:
#             raise SystemExit('请检查脚本内容是否有错')


# if __name__ == '__main__':
#     con = con_omc('omc1')
#     sql_list = parse_sqlfile(sqlfile='../../nokia测试程序相关/sql/test.sql')
#     result = exec_select_sql(con, sql_list[0])
#     print(result)
#     con[0].close()

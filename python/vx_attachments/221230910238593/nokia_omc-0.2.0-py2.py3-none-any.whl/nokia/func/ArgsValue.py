from .Position_arg import Args
# 实例化Args
args = Args()
# 网络类型
network = args.position_arg().network
# sql文件路径
sqlfile = args.position_arg().sqlfile
# 更新配置文件路径
update = args.position_arg().update
# 日期参数
sdate = args.position_arg().sdate
# omc列表信息
omc = args.position_arg().omc
# 查询一次返回行号
rowsize = args.position_arg().rowsize
# 线程数
# num = args.position_arg().num
# 结果保存路径
savepath = args.position_arg().savepath

﻿import cx_Oracle as cx
import sys
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from .BaseInfo import BaseInfo
from .ParseSqlFile import ParseSqlFile
from .ArgsValue import sdate, rowsize, omc

omc_dic = BaseInfo.read_omc_config()


# 执行sql脚本
def execute(omc: str):
    # 查询结果表头
    list_title = []
    # 查询结果内容
    lst_data = []
    '''
    连接oracle执行脚本，输入参数：omc、sql脚本路径、sdate参数默认值为None-->([[data]],[title])
    '''
    try:
        con = cx.connect(
            omc_dic[omc][0],
            omc_dic[omc][1],
            omc_dic[omc][2],
            encoding="UTF-8")
    except Exception as ex:
        print(ex)
        sys.exit()
    # 对列表中的脚本进行循环
    sql_list = ParseSqlFile.parse_sqlfile()
    for sql in sql_list:
        sql_type = ParseSqlFile.get_type(sql)
        # 判断当前执行的脚本类型（drop table 或者 create table 或者select）
        if sql_type == 'DROP' or sql_type == 'drop':
            # 对每段脚本进行try处理，遇到异常，将异常打印到屏幕上
            with con.cursor() as cur:
                try:
                    cur.execute(sql.split(';')[0])
                    continue
                except Exception as ex:
                    # drop table 出现异常  只打印信息，不退出程序
                    print(ex)
                    continue
        elif sql_type == 'CREATE' or sql_type == 'create':
            # create table 语句存在变量
            if "&" in sql.split(';')[0]:
                with con.cursor() as cur:
                    try:
                        str1 = re.sub(
                            r"&.*?,", sdate[0] + ',', sql.split(';')[0], count=1)
                        str2 = re.sub(r"&.*?,", sdate[1] + ',', str1, count=1)
                        cur.execute(str2)
                        print('create table 成功')
                        continue
                    except Exception as ex:
                        print(ex)
                        sys.exit()
            # create table 语句不存在变量
            else:
                with con.cursor() as cur:
                    try:
                        cur.execute(sql)
                        print('create table 成功')
                        continue
                    except Exception as ex:
                        print(ex)
                        sys.exit()
        elif sql_type == 'SELECT' or sql_type == 'select':
            # 如果select语句存在变量
            with con.cursor() as cur:
                try:
                    if "&" in sql.split(';')[0]:
                        cur.execute(sql.split(';')[0], (sdate[0], sdate[1]))
                    else:
                        cur.execute(sql.split(';')[0])
                    # 获取表头信息
                    title = [i[0] for i in cur.description]
                    list_title.append(title)
                    while True:
                        rows = cur.fetchmany(rowsize)
                        if not rows:
                            break
                        for row in rows:
                            lst = []
                            for element in row:
                                lst.append(element)
                            lst.append(omc)
                            lst_data.append(lst)
                    # 返回数据和表头信息
                    return (lst_data, list_title[0] + ['omc归属'])
                except Exception as ex:
                    print(ex)
                    sys.exit()
        else:
            print("未知类型sql语句")
            cur.close()
            con.close()


def multithreading(omc_list: list):
    lst_data = []
    '''
    传入omc列表 -->元组([[data]],[title])
    '''
    with ThreadPoolExecutor(max_workers=len(omc_list)) as t:
        print('-->当前线程数为%d个<--' % (len(omc_list)))
        obj_list = []
        for i in omc_list:
            # 判断如果要查询的omc同时在omc_list和密码本中则执行查询
            if i in omc and i in omc_dic:
                print('正在查询%s...' % i)
                obj = t.submit(execute, i)
                obj_list.append(obj)
            else:
                # 如果不在跳过
                print('%s不存在...' % i[0])
                continue
        for future in as_completed(obj_list):
            # 此处data为元组，第一个元素为二维列表数据，第二个元素为一维列表 表头
            data = future.result()
            try:
                for i in data[0]:
                    lst_data.append(i)
            except BaseException:
                continue
        # 如果查询的omc不存在，或者没有查到数据
        if len(lst_data) == 0:
            return ([[]], [])
        else:
            lst_title = data[1]
            return(lst_data, lst_title)

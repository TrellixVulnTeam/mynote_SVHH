import sqlparse
import cchardet as chardet
from .ArgsValue import sqlfile


class ParseSqlFile:

    @staticmethod
    def get_encoding():
        with open(sqlfile, "rb") as f:
            msg = f.read()
            result = chardet.detect(msg)
            # 如果编码的可信度很高，则直接使用检测出的编码
            if result['confidence'] > 0.9:
                return (result['encoding'])
            # 如果编码的可信度比较低，则使用gb2312编码
            else:
                return 'gb2312'

    @staticmethod
    def parse_sqlfile():
        '''
        解析sql文件，返回sql脚本列表
        '''
        # 获取sql文件编码
        encoding = ParseSqlFile.get_encoding()
        with open(sqlfile, 'r', encoding=encoding) as f:
            sql = f.read()
            # 使用sql解释器返回脚本列表
            return sqlparse.split(sqlparse.format(sql, strip_comments=True))

    @classmethod
    def get_type(cls, sql):
        '''
        不带注释的单段sql语句，返回sql语句类型--drop、create、select...
        如果输入非sql语句，会返回UNKNOWN
        '''
        parsed = sqlparse.parse(sql)
        stmt = parsed[0].tokens
        sql_type = sqlparse.sql.Statement(stmt).get_type()
        return sql_type

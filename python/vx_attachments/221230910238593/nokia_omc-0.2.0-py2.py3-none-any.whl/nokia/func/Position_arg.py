import argparse
from .version import version


class Args:
    @staticmethod
    def position_arg():
        '''
        定义args 返回args
        '''
        parser = argparse.ArgumentParser(
            description='诺基亚omc指标提取', prog='诺基亚omc指标提取')
        # 可传入多个omc，生成一个待查询的omc列表
        subparsers = parser.add_subparsers(
            required=True,
            dest='network',
            title='subcommands',
            description='指定要查询的网络类型',
        )

        parser_4g = subparsers.add_parser(
            '4g', aliases=['4G', 'LTE', 'lte', '4'], help='LTE网络')
        parser_2g = subparsers.add_parser(
            '2g', aliases=['2G', 'GSM', 'gsm', '2'], help='GSM网络')

        parser_2g.add_argument(
            'omc',
            nargs='*',
            default=[
                'omc12',
                'omc13',
                'omc14',
                'omc15',
                'omc17',
                'omc20',
                'omc22',
                'omc24'],
            help='omc12 omc13 omc14....')
        parser_2g.add_argument(
            '-sql',
            '--sqlfile',
            required=False,
            help='要执行的脚本文件')
        parser_2g.add_argument(
            '-u',
            '--update',
            required=False,
            help='更新各个omc的账号密码')
        parser_2g.add_argument(
            '-s',
            '--savepath',
            required=False,
            default='./',
            help='查询结果保存的路径，默认为当前路径')
        # parser_2g.add_argument(
        #     '-n',
        #     '--num',
        #     required=False,
        #     default=20,
        #     type=int,
        #     help='启动线程数量，默认为20个线程')
        parser_2g.add_argument(
            '-r',
            '--rowsize',
            required=False,
            default=500,
            type=int,
            help='查询结果返回行数，默认500行')
        parser_2g.add_argument(
            '--sdate',
            nargs=2,
            metavar=(
                'start_time',
                'end_time'),
            help='针对指标类查询的开始结束时间')

        parser_4g.add_argument(
            'omc',
            nargs='*',
            default=[
                'omc1',
                'omc2',
                'omc3',
                'omc5',
                'omc6',
                'omc26',
                'omc27',
                'omc28',
                'omc29',
                'omc30',
                'omc31',
                'omc32'],
            help='omc1 omc2 omc3....')
        parser_4g.add_argument(
            '-sql',
            '--sqlfile',
            required=False,
            help='要执行的脚本文件')
        parser_4g.add_argument(
            '-u',
            '--update',
            required=False,
            help='更新各个omc的账号密码')
        parser_4g.add_argument(
            '-s',
            '--savepath',
            required=False,
            default='./',
            help='查询结果保存的路径，默认为当前路径')
        # parser_4g.add_argument(
        #     '-n',
        #     '--num',
        #     required=False,
        #     default=20,
        #     type=int,
        #     help='启动线程数量，默认为20个线程')
        parser_4g.add_argument(
            '-r',
            '--rowsize',
            required=False,
            default=500,
            type=int,
            help='查询结果返回行数，默认500行')
        parser_4g.add_argument(
            '--sdate',
            nargs=2,
            metavar=(
                'start_time',
                'end_time'),
            help='针对指标类查询的开始结束时间')

        parser.add_argument(
            '-v',
            '--version',
            action="version",
            version='诺基亚omc指标提取 %s' %
            version,
            help="版本信息")
        args = parser.parse_args()
        return args

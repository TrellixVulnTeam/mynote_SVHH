﻿from pathlib import PurePath
import pandas as pd
import sys
import time
import os
from .ArgsValue import savepath, sqlfile

# 查询结果保存
def save_data(list_data, list_title):
    '''
    输入data列表和title列表，进行数据保存
    '''
    # 如果查询结果为[[]]
    if len(list_data) == 1 and len(list_data[0]) == 0:
        print('未查询到数据...')
        sys.exit()
    else:
        df = pd.DataFrame(list_data, columns=list_title)
        dir = PurePath(savepath)
        df.to_csv(
            str(dir) +
            '/' +
            os.path.splitext(
                os.path.basename(sqlfile))[0] +
            '-%s.csv' %
            time.strftime(
                "%Y%m%d%H%M%S",
                time.localtime()),
            encoding='gb18030',
            index=False)
        print('查询结果已保存至%s' % os.path.abspath(savepath))

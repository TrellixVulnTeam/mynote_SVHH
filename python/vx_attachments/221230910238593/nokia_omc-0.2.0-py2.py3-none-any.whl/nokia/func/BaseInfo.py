import platform
import os
import json
import pickle
from .ArgsValue import network


class BaseInfo:
    def __init__(self) -> None:
        pass

    @staticmethod
    def user_path():
        # 获取当前用户的家目录
        if platform.system().lower() == 'windows':
            user_path = os.environ['USERPROFILE']
        elif platform.system().lower() == 'linux':
            user_path = os.environ['HOME']
        return user_path

    @classmethod
    def update_config(cls, file):
        '''
        打开json配置文件，使用pickle模块将内容写入用户目录下持久保存
        '''
        with open(file, 'r') as f1, open('%s\\.omc账号密码-%s.pickle' % (cls.user_path(), network), 'wb') as f2:
            d = json.loads(f1.read())
            pickle.dump(d, f2)

    # 每次执行查询前需从本地读取omc的配置文件
    @staticmethod
    def read_omc_config():
        '''
        从本地读取omc的配置文件返回字典
        '''
        if os.path.exists(
            '%s\\.omc账号密码-%s.pickle' %
                (BaseInfo.user_path(), network)):
            with open('%s\\.omc账号密码-%s.pickle' % (BaseInfo.user_path(), network), 'rb') as f:
                dic = pickle.load(f)
                return dic
        else:
            raise SystemExit('未找到配置文件')